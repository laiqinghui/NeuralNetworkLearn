# CZ4042: Neural Networks Project 1

The source code for part A and part B can be found in the 'Classification' directory and 'Regression' directory respectively.



